const mongoose=require("mongoose");
const productSchema=new mongoose.Schema({
    productName:{
        type:String,
        required:true,
        unique:true,
        trim:true
    },
    price:{
        type:number,
        required:true,
        min:0.01
    },
    availableStocks:{
        type:number,
        required:true,
        min:0,
        default:0
    }
    },{
        timestamps:true
}
);
module.exports=mongoose.model("Product",productSchema);