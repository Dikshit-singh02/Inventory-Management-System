const express=require("express"); 
const mongoose=require("mongoose");
const dotenv=require("dotenv")

dotenv.config();

const productRoutes=require("./routes/productRoutes");

const app=express();

app.use(express.json);
app.use("./products",productRoutes);
app.get(("./",(req,res)=>{
    res.json({
        message:"Inventary management api is running"
    });
}));

mongoose
    .connect(process.env.MONGO_URI)
    .then(()=>{
        console.log("mongodb connected");
        app.listen(process.env.PORT,()=>{
            console.log("server running on port ${process.env.PORT}");
        });
    })
    .catch((error)=>{
        console.log("mongodb conn error",error.message);
    });

