const express = require("express");

const {
    createProduct,
    getProducts,
    purchaseProduct,
    restockProduct,
    getProductHistory
} = require("../controllers/productController");

const router = express.Router();

// Create product
router.post("/", createProduct);

// Get all products
router.get("/", getProducts);

// Purchase product
router.post("/purchase", purchaseProduct);

// Restock product
router.post("/restock", restockProduct);

// Get product history
router.get("/:productId/history", getProductHistory);

module.exports = router;
